$(function () {
			$("#auto-body").ready(function () {	
                chrome.tabs.query({
                    currentWindow: true,
                    active:true
                },
                function (tabs){        
                    console.log(tabs[0].url);
                    var db = openDatabase("FYP", "1.0", "itemDB", 65535); // itemDB is the database name
                    db.transaction(function (transaction) {
					var sql = "SELECT * FROM items";
					transaction.executeSql(sql, undefined, function (transaction, result) {
						if (result.rows.length) {
							for (var i = 0; i < result.rows.length; i++) {
								var row = result.rows.item(i);
								var item = row.item;
                                var link=tabs[0].url;
                                if(link.indexOf("http://")!=-1){
                                    link=link.substring(link.indexOf("http://")+7);  
                                }
                                if(link.indexOf("https://")!=-1){
                                    link=link.substring(link.indexOf("https://")+8);
                                }
                                while(link.indexOf("/")!=-1){
                                    link=link.substring(0,link.indexOf("/"));
                                }
                                if(link.indexOf("www.")==-1){
                                link="www."+link;
                            }
                                console.log(link);
                                console.log(item)
                                if(item==link){
                                    console.log("matched");
                                    $("#safe").css("display","none");
                                    $("#notsafe").css("display","block");
                                    break;
                                }
							}
						} else {
                            $("#safe").css("display","block");
                            $("#notsafe").css("display","none");
						}
					}, function (transaction, err) {
						alert('No table found. Click on "Create Table" to create table now');
					})
				})
                }
                )
			});
            
			$("#manCheck").click(function () {	
                    var db = openDatabase("FYP", "1.0", "itemDB", 65535); // itemDB is the database name
                    db.transaction(function (transaction) {
					var sql = "SELECT * FROM items";
					transaction.executeSql(sql, undefined, function (transaction, result) {
						if (result.rows.length) {
                            var flag=true;
							for (var i = 0; i < result.rows.length; i++) {
								var row = result.rows.item(i);
								var item = row.item;
                                var link=$("#urlField").val();
                                if(link.indexOf("http://")!=-1){
                                    link=link.substring(link.indexOf("http://")+7);  
                                }
                                if(link.indexOf("https://")!=-1){
                                    link=link.substring(link.indexOf("https://")+8);
                                }
                                while(link.indexOf("/")!=-1){
                                    link=link.substring(0,link.indexOf("/"));
                                }
                                if(link.indexOf("www.")==-1){
                                link="www."+link;
                            }
                                console.log(link);
                                console.log(item)
                                if(item==link){
                                    console.log("matched");
                                    $("#safe").css("display","none");
                                    $("#notsafe").css("display","block");
                                    flag=false;
                                    break;
                                }
							}
                            if(flag){
                                $("#safe").css("display","block");
                                $("#notsafe").css("display","none");

                            }
						} else {
                            $("#safe").css("display","block");
                            $("#notsafe").css("display","none");
						}
					}, function (transaction, err) {
						alert('No table found. Click on "Create Table" to create table now');
					})
				})
			});
		});